package cu.entumovil.snb.core.holders;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.stmt.DeleteBuilder;

import java.sql.SQLException;

import cu.entumovil.snb.R;
import cu.entumovil.snb.SNBApp;
import cu.entumovil.snb.core.models.News;
import cu.entumovil.snb.ui.listeners.OnNewsRowClickListener;

public class HistoryViewHolder extends RecyclerView.ViewHolder {

    private static final String TAG = SNBApp.APP_TAG + HistoryViewHolder.class.getSimpleName();

    private Context context;

    public ImageView img_hitory;

    public TextView txt_history_resume, txt_history_description;

    public HistoryViewHolder(View v) {
        super(v);
        context = v.getContext();
        img_hitory = (ImageView) v.findViewById(R.id.img_hitory);
        txt_history_resume = (TextView) v.findViewById(R.id.txt_history_resume);
        txt_history_description = (TextView) v.findViewById(R.id.txt_history_description);
    }

}
