package cu.entumovil.snb.core.models;

public class Fielder extends Player {

    private int JJ;

    private int GA;

    private String INN;

    private int O;

    private int A;

    private int E;

    private int DP;

    public Fielder() { }

    public int getJJ() {
        return JJ;
    }

    public void setJJ(int JJ) {
        this.JJ = JJ;
    }

    public int getGA() {
        return GA;
    }

    public void setGA(int GA) {
        this.GA = GA;
    }

    public String getINN() {
        return INN;
    }

    public void setINN(String INN) {
        this.INN = INN;
    }

    public int getO() {
        return O;
    }

    public void setO(int o) {
        O = o;
    }

    public int getA() {
        return A;
    }

    public void setA(int a) {
        A = a;
    }

    public int getE() {
        return E;
    }

    public void setE(int e) {
        E = e;
    }

    public int getDP() {
        return DP;
    }

    public void setDP(int DP) {
        this.DP = DP;
    }
}
