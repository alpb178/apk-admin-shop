package cu.entumovil.snb.core.models;

import java.io.Serializable;
import java.util.Date;

public class Game implements Serializable {

    private int idJ;

    private String Fecha;

    private String Hora;

    private String Estadio;

    private String VS;

    private String HC;

    private String Estado;

    private int CVS;

    private int HVS;

    private int EVS;

    private String NomGan;

    private int CHC;

    private int HHC;

    private int EHC;

    private String NomPerd;

    private Linescore linescore;

    public Game() { }

    public int getIdJ() {
        return idJ;
    }

    public void setIdJ(int idJ) {
        this.idJ = idJ;
    }

    public String getFecha() {
        return Fecha;
    }

    public void setFecha(String fecha) {
        Fecha = fecha;
    }

    public String getHora() {
        return Hora;
    }

    public void setHora(String hora) {
        Hora = hora;
    }

    public String getEstadio() {
        return Estadio;
    }

    public void setEstadio(String estadio) {
        Estadio = estadio;
    }

    public int getCVS() {
        return CVS;
    }

    public String getVS() {
        return VS;
    }

    public void setVS(String VS) {
        this.VS = VS;
    }

    public String getHC() {
        return HC;
    }

    public void setHC(String HC) {
        this.HC = HC;
    }

    public String getEstado() {
        return Estado;
    }

    public void setEstado(String estado) {
        Estado = estado;
    }

    public void setCVS(int CVS) {
        this.CVS = CVS;
    }

    public int getHVS() {
        return HVS;
    }

    public void setHVS(int HVS) {
        this.HVS = HVS;
    }

    public int getEVS() {
        return EVS;
    }

    public void setEVS(int EVS) {
        this.EVS = EVS;
    }

    public String getNomGan() {
        return NomGan;
    }

    public void setNomGan(String nomGan) {
        NomGan = nomGan;
    }

    public int getCHC() {
        return CHC;
    }

    public void setCHC(int CHC) {
        this.CHC = CHC;
    }

    public int getHHC() {
        return HHC;
    }

    public void setHHC(int HHC) {
        this.HHC = HHC;
    }

    public int getEHC() {
        return EHC;
    }

    public void setEHC(int EHC) {
        this.EHC = EHC;
    }

    public String getNomPerd() {
        return NomPerd;
    }

    public void setNomPerd(String nomPerd) {
        NomPerd = nomPerd;
    }

    public Linescore getLinescore() {
        return linescore;
    }

    public void setLinescore(Linescore linescore) {
        this.linescore = linescore;
    }
}
