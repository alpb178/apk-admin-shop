package cu.entumovil.snb.core.models;

public class LifeTime extends PlayerDetails {

    private String CP;

    private String SO_BB;

    private String CA;

    private String CI;

    private String BB_SO;

    public LifeTime() { }

    public String getCP() {
        return CP;
    }

    public void setCP(String CP) {
        this.CP = CP;
    }

    public String getSO_BB() {
        return SO_BB;
    }

    public void setSO_BB(String SO_BB) {
        this.SO_BB = SO_BB;
    }

    public String getCA() {
        return CA;
    }

    public void setCA(String CA) {
        this.CA = CA;
    }

    public String getCI() {
        return CI;
    }

    public void setCI(String CI) {
        this.CI = CI;
    }

    public String getBB_SO() {
        return BB_SO;
    }

    public void setBB_SO(String BB_SO) {
        this.BB_SO = BB_SO;
    }
}
