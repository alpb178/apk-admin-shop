package cu.entumovil.snb.core.utils;

public enum FavoriteType {
    NONE,
    PLAYER,
    TEAM
}
