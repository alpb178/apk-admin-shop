package cu.entumovil.snb.core.utils;

public enum GameStates {
    NONE,
    CLOSED,
    DELAYED,
    FINISHED,
    STARTED,
    STOPPED,
    SUSPENDED,
    Demor,
    Deten,
    Susp,
    Sell,
    Encurso,
    Progr,
    Term
}
