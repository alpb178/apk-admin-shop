package cu.entumovil.snb.core.utils;

public enum PositionsType {
    NONE,
    PLAYER,
    PITCHER
}
