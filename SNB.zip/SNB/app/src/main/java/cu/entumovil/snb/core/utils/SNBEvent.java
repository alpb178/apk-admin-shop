package cu.entumovil.snb.core.utils;

public enum SNBEvent {
    UNKNOWN,
    CONNECTED,
    CONNECTION_FAILED,
    CONNECTION_LOST,
    RECONNECTING
}
