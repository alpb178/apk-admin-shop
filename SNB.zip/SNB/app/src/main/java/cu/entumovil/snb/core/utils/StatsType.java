package cu.entumovil.snb.core.utils;

public enum StatsType {
    NONE,
    COLLECTIVE,
    SINGLE,
    SPECIALIZED
}
