package cu.entumovil.snb.ui.listeners;

import android.view.View;

public interface OnGameRowClickListener {

    void onGameRowClick(View gameHolderRow, int position);

}
