package cu.entumovil.snb.ui.listeners;

public interface OnLoadMoreListener {

    void onLoadMore();

}
