package cu.entumovil.snb.ui.listeners;

import android.view.View;

public interface OnNewsRowClickListener {

    void onNewsRowPress(View newsHolderRow, int position);

}
