package cu.entumovil.snb.ui.listeners;

import android.view.View;

public interface OnRowClickListener {

    void onRowPress(View rowPress, int position);

}
