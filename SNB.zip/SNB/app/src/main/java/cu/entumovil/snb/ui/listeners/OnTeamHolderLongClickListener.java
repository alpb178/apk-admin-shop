package cu.entumovil.snb.ui.listeners;

import android.view.View;

public interface OnTeamHolderLongClickListener {

    boolean onTeamRowLongPress(View teamHolderRow, int position);

}
